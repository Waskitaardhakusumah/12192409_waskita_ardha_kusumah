#########
E-Library
#########

E-Library adalah sistem informasi yang berisi data buku, data anggota, transaksi peminjaman, dan laporan data. Projek ini bersifat open-source menggunakan Framework `Code Igniter <http://codeigniter.com>`_.


*******
License
*******

Please see the `license
agreement <https://github.com/bcit-ci/CodeIgniter/blob/develop/user_guide_src/source/license.rst>`_.


***************
Programmers
***************

Arif Febrianto - 12191960 - 12.3A.07
