<script type="text/javascript">
  $('.alet-message').alert().delay(3000).slideUp('slow');
</script>
<script type="text/javascript" src="<?= base_url() . 'assets/js/jquery.js'; ?>"></script>
<script type="text/javascript" src="<?= base_url() . 'assets/js/bootstrap.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/datatable/jquery.datatables.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/datatable/datatables.js'; ?>"></script>
</body>

</html>